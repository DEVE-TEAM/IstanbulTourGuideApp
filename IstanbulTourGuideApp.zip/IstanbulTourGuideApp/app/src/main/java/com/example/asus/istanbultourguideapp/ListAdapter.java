package com.example.asus.istanbultourguideapp;

import android.app.Activity;
import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAdapter extends ArrayAdapter<List_name> {
    private int mImagResourceId;


    public ListAdapter(Context context, ArrayList<List_name> Words, int ImagResourceId) {

        super(context, 0, Words);
        mImagResourceId = ImagResourceId;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if the existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.activity_list_adapter, parent, false);
        }
        List_name cureentName = getItem(position );
        TextView NameTexitview = (TextView) listItemView.findViewById(R.id.namePlace);
        NameTexitview.setText(cureentName.getPlaceNameId());

        // Find the TextView in the list_item.xml layout with the ID version_number
        TextView LocationTexitview = (TextView) listItemView.findViewById(R.id.location);
        // Get the version number from the current AndroidFlavor object and
        // set this text on the number TextView
        LocationTexitview.setText(cureentName.getLocationId());

        // Return the whole list item layout (containing 2 TextViews and an ImageView)
        // so that it can be shown in the ListView
        ImageView imageView = (ImageView)listItemView.findViewById(R.id.imageid);
        if(cureentName.gethasimage()) {
            imageView.setImageResource(cureentName.getmImageResurce_id());
            imageView.setVisibility(View.VISIBLE);
        }
        else {
            imageView.setVisibility(View.GONE);
        }
        // Set the theme color for the list item
        View textContainer = listItemView.findViewById(R.id.contant);
        return listItemView;
    }

}

