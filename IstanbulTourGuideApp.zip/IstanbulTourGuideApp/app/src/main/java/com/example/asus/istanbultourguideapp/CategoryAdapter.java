package com.example.asus.istanbultourguideapp;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class CategoryAdapter extends FragmentPagerAdapter {
private Context mContext;
public CategoryAdapter(Context context , FragmentManager fm){

    super(fm);
    mContext=context;
}
    @Override
    public Fragment getItem(int position) {
    if(position==0){
        return new HotelsFragment();
    }else if(position==1){
        return new RestaurantsFragment();
    }else if(position==2){
        return new MallsFragment();
    }else{
        return new SightsAndLandmarksFragment();
    }
}

    @Override
    public int getCount() {
        return 4;
    }



    @Override
    public CharSequence getPageTitle(int position) {
        if (position == 0) {
            return mContext.getString(R.string.list1);
        } else if (position == 1) {
            return mContext.getString(R.string.list2);
        } else if (position == 2) {
            return mContext.getString(R.string.list3);
        } else {
            return mContext.getString(R.string.list4);
        }
    }
}