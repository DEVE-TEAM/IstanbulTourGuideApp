package com.example.asus.istanbultourguideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HotelsFragment extends Fragment {


    public HotelsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_list_name, container, false);
        final ArrayList<List_name> Nameplac = new ArrayList<List_name>();
        Nameplac.add(new List_name(R.string.Hotel1,R.string.hotalLocation1,R.drawable.soho_house_istanbul));
        Nameplac.add(new List_name(R.string.Hotel2,R.string.hotalLocation2,R.drawable.cvk_park_bosphorus_hotel));
        Nameplac.add(new List_name(R.string.Hotel3,R.string.hotalLocation3,R.drawable.dere_suiteshot));
        Nameplac.add(new List_name(R.string.Hotel4,R.string.hotalLocation4,R.drawable.radisson_blu_hotel));
        ListAdapter adapter = new ListAdapter(getActivity(),Nameplac,R.id.imageid);
        ListView listView = (ListView)rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }
    }


