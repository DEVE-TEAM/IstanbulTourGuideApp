package com.example.asus.istanbultourguideapp;

import android.os.Parcel;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class List_name{
    private int mPlaceName;
    private  int mLocation;
    private int mImageResurce_id = NO_IMAGE_PROVIDE;
    private static final int NO_IMAGE_PROVIDE = -1;


public List_name(int placenameId , int locationId , int imagrResourceId){
    mPlaceName =placenameId;
    mLocation = locationId;
    mImageResurce_id = imagrResourceId;
}
public List_name (int placenameId,int locationId){
    mPlaceName = placenameId;
    mLocation = locationId;

}
protected List_name(Parcel parcel){
  mPlaceName=  parcel.readInt();
  mLocation = parcel.readInt();
  mImageResurce_id=parcel.readInt();

}

    public  int getPlaceNameId() {
        return mPlaceName;
    }
    public  int getLocationId() {
        return mLocation;
    }
    public  int getmImageResurce_id() {
        return mImageResurce_id;
    }
    public  boolean gethasimage(){
        return mImageResurce_id != NO_IMAGE_PROVIDE;
    }
}
