package com.example.asus.istanbultourguideapp;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class RestaurantsFragment extends Fragment {


    public RestaurantsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_list_name, container, false);
        final ArrayList<List_name> Nameplac = new ArrayList<List_name>();
        Nameplac.add(new List_name(R.string.Rosturant1,R.string.RosturantLocation2,R.drawable.sofya_kebab));
        Nameplac.add(new List_name(R.string.Rosturant2,R.string.RosturantLocation2,R.drawable.outdoor_seating));
        Nameplac.add(new List_name(R.string.Rosturant3,R.string.RosturantLocation3,R.drawable.testi_kebab));
        Nameplac.add(new List_name(R.string.Rosturant2,R.string.RosturantLocation2,R.drawable.olive_restaurant));
        ListAdapter adapter = new ListAdapter(getActivity(),Nameplac,R.id.imageid);
        ListView listView = (ListView)rootView.findViewById(R.id.list);
        listView.setAdapter(adapter);
        return rootView;
    }

}
